# Gerard Butler Fan Experience — standalone rebuild

This ZIP is a standalone HTML/CSS/JavaScript rebuild implementing the requested fan-account interface.

## Included
- Login / Sign Up / Logout navigation
- Fan registration and validation
- Browser-side SHA-256 password hashing for demonstration
- Session-like account state
- Forgot-password interface
- Protected fan dashboard
- VIP ticket information area
- Meet-and-greet request status UI
- Events, profile and security sections
- Private admin-area interface
- Terms and Privacy pages
- Responsive dark/gold design
- Clear unofficial-fan disclosure

## Production security requirement
This is a frontend standalone demo, not a complete production authentication server. Browser localStorage cannot provide the same security as a real backend.

Before accepting real users or payments, connect the authentication UI to a reputable server-side identity/authentication service. The production system should provide:
- salted password hashing such as Argon2id/bcrypt/scrypt
- secure, HttpOnly, SameSite session cookies
- email verification
- expiring password-reset tokens
- rate limiting and brute-force protection
- CSRF protection
- server-side authorization for the admin role
- HTTPS
- audit logging
- secure database storage

Do not put an administrator password or secret API key in frontend JavaScript.

## Important authenticity note
The site intentionally does NOT label any email address as “Official Gerard Butler Management” and does not claim affiliation or endorsement. Such a representation should only be published after independent verification and authorization.

## Deploy
Upload the files to any static hosting provider for the demo. For production authentication, deploy the frontend with a backend/auth provider and replace the demo auth functions in `auth.js`.
