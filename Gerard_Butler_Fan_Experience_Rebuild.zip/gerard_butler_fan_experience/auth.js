const usersKey="gb_demo_users";
async function hashPassword(p){const data=new TextEncoder().encode(p);const buf=await crypto.subtle.digest("SHA-256",data);return [...new Uint8Array(buf)].map(x=>x.toString(16).padStart(2,"0")).join("")}
function users(){try{return JSON.parse(localStorage.getItem(usersKey)||"[]")}catch(e){return[]}}
function saveUsers(u){localStorage.setItem(usersKey,JSON.stringify(u))}
function msg(el,text,ok=false){el.className="message "+(ok?"success":"error");el.textContent=text}
document.addEventListener("DOMContentLoaded",()=>{
 const sf=document.getElementById("signupForm");
 if(sf)sf.addEventListener("submit",async e=>{e.preventDefault();const name=document.getElementById("name").value.trim(),email=document.getElementById("email").value.trim().toLowerCase(),p=document.getElementById("password").value,c=document.getElementById("confirm").value,country=document.getElementById("country").value,m=document.getElementById("message");if(p!==c)return msg(m,"Passwords do not match.");if(p.length<10)return msg(m,"Password must be at least 10 characters.");if(users().some(u=>u.email===email))return msg(m,"An account with this email already exists.");const u={name,email,country,passwordHash:await hashPassword(p),createdAt:new Date().toISOString()};const all=users();all.push(u);saveUsers(all);localStorage.setItem("gb_current_user",JSON.stringify({name,email,country}));location.href="account.html"});
 const lf=document.getElementById("loginForm");
 if(lf)lf.addEventListener("submit",async e=>{e.preventDefault();const email=document.getElementById("email").value.trim().toLowerCase(),p=document.getElementById("password").value,m=document.getElementById("message"),h=await hashPassword(p),u=users().find(x=>x.email===email&&x.passwordHash===h);if(!u)return msg(m,"Invalid email or password.");localStorage.setItem("gb_current_user",JSON.stringify({name:u.name,email:u.email,country:u.country}));location.href="account.html"});
 const rf=document.getElementById("resetForm");
 if(rf)rf.addEventListener("submit",e=>{e.preventDefault();msg(document.getElementById("message"),"Check your email for instructions to reset your password.",true)});
 const pf=document.getElementById("profileForm");
 if(pf){const u=currentUser();if(!u)return;document.getElementById("userName").textContent=u.name;document.getElementById("profileName").value=u.name;document.getElementById("profileCountry").value=u.country||"";document.getElementById("dashboardContent").hidden=false;pf.addEventListener("submit",e=>{e.preventDefault();const n=document.getElementById("profileName").value.trim(),c=document.getElementById("profileCountry").value.trim(),cur=currentUser();cur.name=n;cur.country=c;localStorage.setItem("gb_current_user",JSON.stringify(cur));document.getElementById("userName").textContent=n})}
 const gate=document.getElementById("accountGate");if(gate&&!currentUser()){gate.innerHTML='<div class="auth-card"><h1>Login required</h1><p>Please log in to access your fan dashboard.</p><a class="btn primary" href="login.html">LOGIN</a></div>'}
 const af=document.getElementById("adminForm");
 if(af)af.addEventListener("submit",e=>{e.preventDefault();msg(document.getElementById("message"),"Admin authentication must be connected to a real server-side identity provider before deployment.",false)});
});